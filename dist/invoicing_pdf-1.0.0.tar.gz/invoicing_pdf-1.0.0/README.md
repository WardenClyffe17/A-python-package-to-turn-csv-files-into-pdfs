# What is this project?
This is an app that creates PDF invoices out of Excel files.